# DirectoryGraphQl

**DirectoryGraphQl** provides type and resolver information for the GraphQl module
to generate directory information endpoints.
